from django.apps import AppConfig


class PuzzleConfig(AppConfig):
    name = 'puzzle'
